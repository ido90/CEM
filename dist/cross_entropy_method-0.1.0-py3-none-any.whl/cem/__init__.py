'''Cross Entropy Method for either tail-sampling or optimization.'''
from cem.CEM import CEM
from cem import examples