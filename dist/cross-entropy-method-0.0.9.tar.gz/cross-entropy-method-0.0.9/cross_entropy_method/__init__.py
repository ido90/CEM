'''Cross Entropy Method for either tail-sampling or optimization.'''
from cross_entropy_method.CEM import CEM
from cross_entropy_method import examples